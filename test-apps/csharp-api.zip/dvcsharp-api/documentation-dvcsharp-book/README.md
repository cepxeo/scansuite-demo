# Damn Vulnerable C# Web Application (DVCSharp)

*DVCSharp* is an intentionally vulnerable API first web application created to demonstrate and practice common vulnerabilities affecting C# based web applications written for .NET Core framework.

